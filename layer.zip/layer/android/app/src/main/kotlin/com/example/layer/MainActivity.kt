package com.example.layer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
