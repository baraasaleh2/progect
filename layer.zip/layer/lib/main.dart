import 'dart:developer';

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
        home: Scaffold(
            body: ListView(
                padding:  EdgeInsets.all(10),
                children: [
                  Text(
                    'Center',
                    style: TextStyle(
                      color: Colors.black,
                    ),
                  ),

                  Container(
                      padding: EdgeInsets.all(15),
                      height: 150,
                      child: Card(
                          color: Colors.blue,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Row(
                                  children: [


                                    Expanded(
                                      child: Container(
                                          padding: EdgeInsets.all(5),
                                          child: Column(
                                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Row(
                                                  children: [
                                                    Text(
                                                      'Mausam Rayamajhi  ',

                                                      style: TextStyle(
                                                          fontSize: 18,
                                                          color: Colors.white),
                                                    ),


                                                  ],
                                                ),
                                                Text(
                                                    'A trendsester',
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                    )
                                                )
                                              ]
                                          )
                                      ),
                                    ),
                                  ]
                              ),


                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Column(
                                        children: [
                                          Text(
                                            '864',
                                            style: TextStyle(
                                                fontSize: 20,
                                                color: Colors.white),
                                          ),
                                          Text(
                                            'Collect',
                                            style: TextStyle(
                                              color: Colors.white,
                                            ),
                                          ),

                                        ]
                                    ),
                                    Column(
                                      children: [
                                        Text(
                                          '51',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.white),
                                        ),
                                        Text(
                                          'Attention',
                                          style: TextStyle(
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                        children: [
                                          Text(
                                            '267',
                                            style: TextStyle(
                                                fontSize: 20,
                                                color: Colors.white),
                                          ),
                                          Text(
                                            'Track',
                                            style: TextStyle(
                                              color: Colors.white,
                                            ),
                                          ),
                                        ]
                                    ),
                                    Column(
                                      children: [
                                        Text(
                                          '39',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.white),
                                        ),
                                        Text(
                                          'Coupons',
                                          style: TextStyle(
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ]
                              ),
                            ],
                          )


                      )
                  ),
                  Container(
                      padding: EdgeInsets.all(10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Column(
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.white,
                                child: Icon(
                                  Icons.account_balance_wallet,
                                  size: 25,
                                  color: Colors.black,
                                ),
                              ),
                              Text('Wallet')
                            ],
                          ),
                          Column(
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.white,
                                child: Icon(
                                  Icons.local_shipping,
                                  size: 25,
                                  color: Colors.black,
                                ),
                              ),
                              Text('Delivery')
                            ],
                          ),
                          Column(
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.white,
                                child: Icon(
                                  Icons.message,
                                  size: 25,
                                  color: Colors.black,
                                ),
                              ),
                              Text('Message')
                            ],
                          ),
                          Column(
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.white,
                                child: Icon(
                                  Icons.monetization_on,
                                  size: 25,
                                  color: Colors.black,
                                ),
                              ),
                              Text('Service')
                            ],
                          ),
                        ],
                      )
                  ),

                  Container(
                    height: 100,

                      child: Row(

                        children: [
                          Container(
                              alignment: Alignment.centerLeft,
                              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                              child: CircleAvatar(
                                backgroundColor: Colors.deepPurpleAccent[200],
                                radius: 20,
                                child: Icon(
                                  Icons.location_on,
                                  color: Colors.white,
                                ),
                              )),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),

                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Address',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            ),
                                      ),
                                      Text(
                                        'Ensure your harvesting address',
                                        style: TextStyle(
                                            color: Colors.grey,

                                      )
                                      ),
                            ],
                                  ),
                                  Icon(
                                    Icons.arrow_forward_ios,
                                    color: Colors.grey[400],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                  Container(
                    height: 100,

                    child: Row(

                      children: [
                        Container(
                            alignment: Alignment.centerLeft,
                            padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                            child: CircleAvatar(
                              backgroundColor: Colors.deepPurpleAccent[200],
                              radius: 20,
                              child: Icon(
                                Icons.lock,
                                color: Colors.white,
                              ),
                            )),
                        Expanded(
                          child: Container(
                            padding: EdgeInsets.fromLTRB(20, 20, 20, 20),

                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                              Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Privacy',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'System permission change',
                                  style: TextStyle(
                                    color: Colors.grey,

                                  )
                                ),

                                ],
                              ),
                                Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.grey[400],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 100,

                    child: Row(

                      children: [
                        Container(
                            alignment: Alignment.centerLeft,
                            padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                            child: CircleAvatar(
                              backgroundColor: Colors.deepPurpleAccent[200],
                              radius: 20,
                              child: Icon(
                                Icons.layers,
                                color: Colors.white,
                              ),
                            )),
                        Expanded(
                          child: Container(
                            padding: EdgeInsets.fromLTRB(20, 20, 20, 20),

                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                              Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'General',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Basic functional settings',
                                  style: TextStyle(
                                    color: Colors.grey,

                                  )
                                ),
                              ],
                            ),

                                Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.grey[400],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 100,

                    child: Row(

                      children: [
                        Container(
                            alignment: Alignment.centerLeft,
                            padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                            child: CircleAvatar(
                              backgroundColor: Colors.deepPurpleAccent[200],
                              radius: 20,
                              child: Icon(
                                Icons.notifications,
                                color: Colors.white,
                              ),
                            )),
                        Expanded(
                          child: Container(
                            padding: EdgeInsets.fromLTRB(20, 20, 20, 20),

                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                              Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Notification',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Take over the news on time',
                                  style: TextStyle(
                                    color: Colors.grey,

                                  )
                                ),
                              ],
                            ),

                                Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.grey[400],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),



                ]
            )
        )
    );








  }
}


